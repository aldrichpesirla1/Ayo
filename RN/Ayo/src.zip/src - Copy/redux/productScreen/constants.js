export const ActionTypes = {
      SET_NAME: "src/screens/signupScreen/SET_NAME",
      SET_DESCRIPTION: "src/screens/signupScreen/SET_DESCRIPTION",
      SET_PRICE : "src/screens/signupScreen/SET_PRICE", 
      SET_IN_STOCK : "src/screens/signupScreen/SET_IN_STOCK", 
      SET_PRODUCT_IMG: "src/screens/signupScreen/SET_PRODUCT_IMG", 
}