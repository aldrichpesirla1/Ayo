export const ActionTypes = {
      SET_USERS: "src/screens/apiTestScreen/SET_USERS",
}