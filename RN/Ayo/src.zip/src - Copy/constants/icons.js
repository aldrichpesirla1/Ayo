import Image1 from '../assets/icon.png';

export const icons = {
      homeScreenButton1: Image1, 
}